#include <iostream>
#include "hmm.h"
#include "Number.h"

using namespace std;
void formatData();
int main()
{
    formatData();
    /*
    Number number1(2,-400),number2(0,-10000);
    Number number3;
    number1=number1-number2;
    std::cout<<number1.getValue()<<" "<<number1.getPower()<<std::endl;
    //chromosome bin numbers from chromosome 1 to 22, to X, and to Y. Bin size is 200bp
    int chrBin[25]={0,1235999, 1213756,997234, 956315,904189, 854485,794107, 731374, 702211, 676874, 672262, 661448,
     570640, 531803, 501695, 444111, 393274, 380586, 319033, 312180, 234722, 247645, 774569, 288708};

    int seed=77,state=5,mark=41;//seed of random number generator is 77.
    //It is used to generate random state emission probabilities and transition states.
    //total number states can be set from 2 to 80 and modification marks have to be 41.
    HMM hmm(seed,state,mark);//init HMM model with parameters.
    hmm.generateInitParameters();//initiate random transition states and emission states
    hmm.writeStateToFile();//save the state to File
    hmm.printState();
    for (int i=1;i<25;i++){
        if (i==23) hmm.setChr("chrX");
        else if (i==24) hmm.setChr("chrY");
        else {
            stringstream ss;
            string tmp;
            ss<<i;
            ss>>tmp;
            hmm.setChr("chr"+tmp);
        }
        //We learn chr1 first. It can be chr2-chr22,chrX,chrY
        hmm.setBins(chrBin[i]);//bin size of chr1 and it should be set based on the chromosome size/200+1
        hmm.generateChr();//generate modification marks for chosen chromosome
        hmm.generateEmissionMatrix();//cached the expensive emission state calculation
        hmm.generateForwardMatrix();//generate forward matrix for chosen chromosome
        hmm.generateBackwardMatrix();//generate backward matrix for chosen chromosome
        hmm.EM();//update transition and emission state
        hmm.writeStateToFile();//save the state to File
        hmm.printState();
    }
    */
    return 0;
}
void formatData(){
    std::fstream Emission_Pkm,Transition_bij,InitK,EndK;
    Emission_Pkm.open("Emission-Pkm.txt",std::ios::in|std::ios::out|std::ios::app);
    Transition_bij.open("Transition-bij.txt",std::ios::in|std::ios::out|std::ios::app);
    InitK.open("InitK.txt",std::ios::in|std::ios::out|std::ios::app);
    EndK.open("EndK.txt",std::ios::in|std::ios::out|std::ios::app);
    std::vector<std::vector<double>>emission,transition,start,end;
    int state=5,mark=41,models=4;
    double value;
    //read and write back emission matrix for 4 models
    for (int i=0;i<state*models;i++){
        std::vector<double> row;
        for (int j=0;j<mark;j++){
            Emission_Pkm>>value;
            row.push_back(value);
        }
        emission.push_back(row);
    }
    Emission_Pkm.clear();
    Emission_Pkm.seekp(0,ios::end);
    for (int i=0;i<emission.size();i++){
        for (int j=0;j<emission[i].size();j++){
            Emission_Pkm<<emission[i][j]<<", ";
        }
        Emission_Pkm<<"\n";
    }
    //read and write back transition matrix for 4 models
    for (int i=0;i<state*models;i++){
        std::vector<double> row;
        for (int j=0;j<state;j++){
            Transition_bij>>value;
            row.push_back(value);
        }
        transition.push_back(row);
    }
    Transition_bij.clear();
    Transition_bij.seekp(0,ios::end);
    for (int i=0;i<transition.size();i++){
        for (int j=0;j<transition[i].size();j++){
            Transition_bij<<transition[i][j]<<", ";
        }
        Transition_bij<<"\n";
    }
    //read and write back initial transition matrix for 4 models
    for (int i=0;i<models;i++){
        std::vector<double>row;
        for (int j=0;j<state;j++){
            InitK>>value;
            row.push_back(value);
        }
        start.push_back(row);
    }
    InitK.clear();
    InitK.seekp(0,ios::end);
    for (int i=0;i<models;i++){
        for (int j=0;j<state;j++){
            InitK<<start[i][j]<<", ";
        }
        InitK<<"\n";
    }
    //read and write back ending transition matrix for 4 models
    for (int i=0;i<models;i++){
        std::vector<double>row;
        for (int j=0;j<state;j++){
            EndK>>value;
            row.push_back(value);
        }
        end.push_back(row);
    }
    EndK.clear();
    EndK.seekp(0,ios::end);
    for (int i=0;i<models;i++){
        for (int j=0;j<state;j++){
            EndK<<end[i][j]<<", ";
        }
        EndK<<"\n";
    }

    Emission_Pkm.close();
    Transition_bij.close();
    InitK.close();
    EndK.close();

}
