#include "hmm.h"
HMM::HMM(){
    seed=77;
    state=51;
    mark=41;
}
HMM::HMM(int seed,int state=51,int mark=41){
    this->seed=seed;
    this->state=state;
    this->mark=mark;
}
void HMM::setSeed(int seed){
    this->seed=seed;
}
int HMM::getSeed(){
    return seed;
}
void HMM::setState(int state=51){
    this->state=state;
}
int HMM::getState(){
    return state;
}
void HMM::setMark(int mark=41){
    this->mark=mark;
}
int HMM::getMark(){
    return mark;
}
void HMM::setChr(std::string chr){
    this->chr=chr;
}
std::string HMM::getChr(){
    return chr;
}
void HMM::setBins(int bins){
    this->bins=bins;
}
int HMM::getBins(){
    return bins;
}

void HMM::generateInitParameters(){
    //set seed for random number
    srand(seed);
    //generate random emission matrix
    for (int i=0;i<state;i++){
        std::vector<Number> tmp;
        for (int j=0;j<mark;j++){
            Number number(0);
            tmp.push_back(number);
        }
        emission.push_back(tmp);
    }
    for (int i=0;i<state;i++){
        for (int j=0;j<mark;j++){
            Number number(rand()%100/100.0);
            emission[i][j]=number;
        }
    }
    //generate random transition matrix
    for (int i=0;i<state;i++){
        std::vector<Number> tmp;
        for (int j=0;j<state;j++){
            Number number(0);
            tmp.push_back(number);
        }
        transition.push_back(tmp);
    }
    for (int i=0;i<state;i++){
        for (int j=0;j<1000;j++){
            Number number(0.001);
            transition[i][rand()%state]+=number;
        }
    }
    //transition matrix from start to K state
    for (int i=0;i<state;i++){
        Number number(0);
        start.push_back(number);
    }
    for (int i=0;i<1000;i++){
        Number number(0.001);
        start[rand()%state]+=number;
    }
    //transition matrix from K state to end state
    for (int i=0;i<state;i++){
        Number number(0);
        end.push_back(number);
    }
    for (int i=0;i<1000;i++){
        Number number(0.001);
        end[rand()%state]+=number;
    }
}
void HMM::printState(){
    std::cout<<"Emission state Pkm"<<std::endl;
    for (int i=0;i<state;i++){
        for (int j=0;j<mark;j++){
            std::cout<<std::fixed<<std::setprecision(6)<<emission[i][j].getValue()<<(emission[i][j].getPower()>0?"e+":"e")<<emission[i][j].getPower()<<" ";
        }
        std::cout<<std::endl;
    }
    std::cout<<"State transition prob"<<std::endl;
    for (int i=0;i<state;i++){
        for (int j=0;j<state;j++){
            std::cout<<std::fixed<<std::setprecision(6)<<transition[i][j].getValue()<<(transition[i][j].getPower()>0?"e+":"e")<<transition[i][j].getPower()<<" ";
        }
        std::cout<<std::endl;
    }
    std::cout<<"Transition from start"<<std::endl;
    for (int i=0;i<state;i++){
        std::cout<<std::setprecision(6)<<start[i].getValue()<<(start[i].getPower()>0?"e+":"e")<<start[i].getPower()<<" ";
    }
    std::cout<<std::endl;
    std::cout<<"Transition from end"<<std::endl;
    for (int i=0;i<state;i++){
        std::cout<<std::setprecision(6)<<end[i].getValue()<<(end[i].getPower()>0?"e+":"e")<<end[i].getPower()<<" ";
    }
    std::cout<<std::endl;
}

void HMM::writeStateToFile(){
    std::fstream Emission_Pkm,Transition_bij,InitK,EndK;
    Emission_Pkm.open("Emission-Pkm.txt",std::ios::out|std::ios::app);
    Transition_bij.open("Transition-bij.txt",std::ios::out|std::ios::app);
    InitK.open("InitK.txt",std::ios::out|std::ios::app);
    EndK.open("EndK.txt",std::ios::out|std::ios::app);
    Emission_Pkm<<chr<<" emission Pkm\n";
    for (int i=0;i<state;i++){
        for (int j=0;j<mark;j++){
            Emission_Pkm<<std::fixed<<std::setprecision(6)<<emission[i][j].getValue()<<(emission[i][j].getPower()>0?"e+":"e")<<emission[i][j].getPower()<<" ";
        }
        Emission_Pkm<<"\n";
    }
    Transition_bij<<chr<<" transition bij\n";
    for (int i=0;i<state;i++){
        for (int j=0;j<state;j++){
            Transition_bij<<std::fixed<<std::setprecision(6)<<transition[i][j].getValue()<<(transition[i][j].getPower()>0?"e+":"e")<<transition[i][j].getPower()<<" ";
        }
            Transition_bij<<"\n";
    }
    InitK<<chr<<" transition from start\n";
    for (int i=0;i<state;i++){
        InitK<<std::fixed<<std::setprecision(6)<<start[i].getValue()<<(start[i].getPower()>0?"e+":"e")<<start[i].getPower()<<" ";
    }
    InitK<<"\n";
    EndK<<chr<<" transition from end\n";
    for (int i=0;i<state;i++){
        EndK<<std::fixed<<std::setprecision(6)<<end[i].getValue()<<(end[i].getPower()>0?"e+":"e")<<end[i].getPower()<<" ";
    }
    EndK<<"\n";
}

void HMM::generateChr(){
    V.clear();
    std::ifstream combined2("combined2.txt");
    std::string line;
    bool chr_finished=false;
    while (getline(combined2,line)&&!chr_finished){
        std::stringstream ss(line);
        std::string str;
        ss>>str;
        if (str==chr){
            int curr_bin=0;
            std::vector<int> row;
            while(getline(combined2,line)){
                if (line=="") continue;
                if (line.find("chr")!=std::string::npos) {
                        chr_finished=true;
                        break;
                }
                std::stringstream ss(line);
                int pos;
                ss>>pos;
                while (curr_bin<pos/200){
                    row.clear();
                    for (int i=0;i<mark;i++){
                        row.push_back(0);
                    }
                    V.push_back(row);
                    curr_bin++;
                }
                row.clear();
                for (int i=0;i<mark;i++){
                    int value;
                    ss>>value;
                    row.push_back(value);
                }
                V.push_back(row);
                curr_bin++;
            }
            while (curr_bin<bins){
                row.clear();
                for (int i=0;i<mark;i++){
                    row.push_back(0);
                }
                V.push_back(row);
                curr_bin++;
            }
        }
    }
}
void HMM::generateEmissionMatrix(){
    emissionMatrix.clear();
    Number value(1);
    for (int bin=0;bin<bins;bin++){
        std::vector<Number>row;
        for (int k=0;k<state;k++){
            value=Number(1);
            for (int m=0;m<mark;m++){
                if (V[bin][m]==0){
                    value*=(Number(1)-emission[k][m]);
                }else{
                    value*=emission[k][m];
                }
            }
            row.push_back(value);
        }
        emissionMatrix.push_back(row);
    }
}

void HMM::writeMarkToFile(){
    std::fstream curr_chr(chr+".txt",std::ios::out|std::ios::trunc);
    std::string line;
    for (int i=0;i<bins;i++){
        curr_chr<<i*200<<" ";
        for (int j=0;j<mark;j++){
            curr_chr<<V[i][j]<<" ";
        }
        curr_chr<<"\n";
    }
}

void HMM::readStateFromFile(){
    std::ifstream Emission_Pkm,Transition_bij,InitK,EndK;
    Emission_Pkm.open("Emission-Pkm.txt");
    Transition_bij.open("Transition-bij.txt");
    InitK.open("InitK.txt");
    EndK.open("EndK.txt");
    emission.clear();
    double value;
    long long power;
    for (int i=0;i<state;i++){
        std::vector<Number> row;
        for (int j=0;j<mark;j++){
            Emission_Pkm>>value>>power;
            row.push_back(Number(value,power));
        }
        emission.push_back(row);
    }
    transition.clear();
    for (int i=0;i<state;i++){
        std::vector<Number> row;
        for (int j=0;j<state;j++){
            Transition_bij>>value>>power;
            row.push_back(Number(value,power));
        }
        transition.push_back(row);
    }
    start.clear();
    for (int i=0;i<state;i++){
        InitK>>value>>power;
        start.push_back(Number(value,power));
    }
    end.clear();
    for (int i=0;i<state;i++){
        EndK>>value>>power;
        end.push_back(Number(value,power));
    }
    Emission_Pkm.close();
    Transition_bij.close();
    InitK.close();
    EndK.close();
}

void HMM::generateForwardMatrix(){
    forwardMatrix.clear();
    Number value(0);
    //init scale vector with size of chromosome bins
    for (int bin=0;bin<bins;bin++){
        std::vector<Number> row;
        for (int k=0;k<state;k++){
            Number number(0);
            row.push_back(number);
        }
        forwardMatrix.push_back(row);
    }
    //forward algorithm previous and current state
    for (int k=0;k<state;k++){
        forwardMatrix[0][k]=start[k]*emissionMatrix[0][k];
    }
    for (int bin=1;bin<bins;bin++){
        for (int k=0;k<state;k++){
            Number curr_state_val(0);
            for (int pk=0;pk<state;pk++){
                curr_state_val+=(transition[pk][k]*forwardMatrix[bin-1][pk]);
            }
            forwardMatrix[bin][k]=curr_state_val*emissionMatrix[bin][k];
        }
    }
    px_f=Number(0);
    for (int k=0;k<state;k++){
        px_f+=(forwardMatrix[bins-1][k]*end[k]);
    }
    std::cout<<chr<<" probability px from forward algorithm is:"<<std::scientific<<px_f.getValue()<<" "<<"scale factor is "<<px_f.getPower()<<std::endl;
}

void HMM::generateBackwardMatrix(){
    backwardMatrix.clear();
    Number value(0);
    for (int bin=0;bin<bins;bin++){
        std::vector<Number> row;
        for (int k=0;k<state;k++){
            row.push_back(Number(0));
        }
        backwardMatrix.push_back(row);
    }
    for (int k=0;k<state;k++){
        backwardMatrix[bins-1][k]=end[k];
    }
    for (int bin=bins-2;bin>=0;bin--){
        for (int k=0;k<state;k++){
            value=Number(0);
            for (int nk=0;nk<state;nk++){
               value+=transition[k][nk]*emissionMatrix[bin+1][nk]*backwardMatrix[bin+1][nk];
            }
            backwardMatrix[bin][k]=value;
        }
    }
    px_b=Number(0);
    for (int k=0;k<state;k++){
        px_b+=start[k]*emissionMatrix[0][k]*backwardMatrix[0][k];
    }
    std::cout<<chr<<" probability px from backward algorithm is: "<<std::scientific<<px_b.getValue()<<" scale factor:"<<px_b.getPower()<<std::endl;
}

void HMM::EM(){
    Number value(0);
    std::vector<std::vector<Number>> emissionNumerator(state,std::vector<Number>(mark,0));
    std::vector<std::vector<Number>> emissionDenominator(state,std::vector<Number>(mark,0));
    std::vector<std::vector<Number>> updatedEmission(state,std::vector<Number>(mark,0));
    for (int k=0;k<state;k++){
        for (int m=0;m<mark;m++){
            for (int bin=0;bin<bins;bin++){
                value=forwardMatrix[bin][k]*backwardMatrix[bin][k]/px_f;
                emissionNumerator[k][m]+=value*Number(V[bin][m]);
                emissionDenominator[k][m]+=value;
            }
        }
    }
    for (int k=0;k<state;k++){
        for (int m=0;m<mark;m++){
            updatedEmission[k][m]=emissionNumerator[k][m]/emissionDenominator[k][m];
        }
    }
    std::vector<Number> updatedStart(state,0);
    Number sumStart(0);
    for (int k=0;k<state;k++){
        updatedStart[k]=start[k]*emissionMatrix[0][k]*backwardMatrix[0][k]/px_f;
        sumStart+=updatedStart[k];
    }
    for (int k=0;k<state;k++){
        updatedStart[k]=updatedStart[k]/sumStart;
    }
    std::vector<Number> updatedEnd(state,0);
    Number sumEnd(0);
    for (int k=0;k<state;k++){
        updatedEnd[k]=forwardMatrix[bins-1][k]*end[k]/px_f;
        sumEnd+=updatedEnd[k];
    }
    for (int k=0;k<state;k++){
        updatedEnd[k]=updatedEnd[k]/sumEnd;
    }
    std::vector<std::vector<Number>>updatedTransition(state,std::vector<Number>(state,0));
    std::vector<Number>sumTranisitonK(state,0);
    for (int k=0;k<state;k++){
        for (int nk=0;nk<state;nk++){
            for(int bin=0;bin<bins-1;bin++){
                updatedTransition[k][nk]+=forwardMatrix[bin][k]*transition[k][nk]*emissionMatrix[bin+1][nk]*backwardMatrix[bin+1][nk]/px_f;
            }
            sumTranisitonK[k]+=updatedTransition[k][nk];
        }
    }
    for (int k=0;k<state;k++){
        for (int nk=0;nk<state;nk++){
            updatedTransition[k][nk]=updatedTransition[k][nk]/sumTranisitonK[k];
        }
    }
    emission=updatedEmission;
    transition=updatedTransition;
    start=updatedStart;
    end=updatedEnd;
}
HMM::~HMM()
{
    //dtor
}
