#include "Number.h"

Number::Number(double value, long long power)
{
    this->value=value;
    this->power=power;
    adjustNumber(*this);
}
Number::Number(){
}
double Number::getValue(){
    return value;
}
long long Number::getPower(){
    return power;
}
const Number Number::operator+(const Number &n) const{
    if (this->value==0) return n;
    if (n.value==0) return *this;
    long long max_power;
    double add_value;
    max_power=std::max(this->power,n.power);
    if (std::isnan(this->value/std::pow(10,max_power-this->power))){
        add_value=n.value;
    }else if (std::isnan(n.value/std::pow(10,max_power-n.power))){
        add_value=this->value;
    }else {
        add_value=this->value/std::pow(10,max_power-this->power)+n.value/std::pow(10,max_power-n.power);
    }
    Number add_number(add_value,max_power);
    return add_number;
}
Number & Number::operator+=(const Number& n){
    *this=*this+n;
    return *this;
}
Number & Number::operator*=(const Number& n){
    *this=*this*n;
    return *this;
}

const Number Number::operator-(const Number &n) const{
    if (this->value==0) return n*Number(-1);
    if (n.value==0) return *this;
    long long max_power;
    double sub_value;
    max_power=std::max(this->power,n.power);
    if (std::isnan(this->value/std::pow(10,max_power-this->power))){
        sub_value=-n.value;
    }else if (std::isnan(n.value/std::pow(10,max_power-n.power))){
        sub_value=this->value;
    }else {
        sub_value=this->value/std::pow(10,max_power-this->power)-n.value/std::pow(10,max_power-n.power);
    }
    Number sub_number(sub_value,max_power);
    return sub_number;
}
Number& Number::operator=(const Number &n){
    if (this!=&n){
        this->value=n.value;
        this->power=n.power;
    }
    return *this;
}
const Number Number::operator*(const Number& n)const{
    double multi_value=this->value*n.value;
    long long multi_power=this->power+n.power;
    Number multi_number(multi_value,multi_power);
    return multi_number;
}
const Number Number::operator/(const Number& n)const{
    if (n.value!=0){
        double div_value=this->value/n.value;
        long long div_power=this->power-n.power;
        Number div_number(div_value,div_power);
        return div_number;
    }
    std::cout<<"you try to divide by zero"<<std::endl;
}
void Number::adjustNumber(Number &n){
    int sign=1;
    if (n.value<0){
        sign=-1;
        n.value=-n.value;
    }
    while (n.value>=10){
        n.value/=10;
        n.power++;
    }
    while (n.value<1&&n.value!=0){
        n.value*=10;
        n.power--;
    }
    n.value*=sign;
    if (n.value==0) n.power=0;
}
Number::~Number()
{
    //dtor
}
