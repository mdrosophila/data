#ifndef HMM_H
#define HMM_H
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <climits>
#include <Number.h>
class HMM
{
    public:
        HMM();
        HMM(int seed,int state,int mark);
        void generateInitParameters();
        void printState();
        void writeStateToFile();
        void readStateFromFile();
        void generateChr();
        void writeMarkToFile();
        void generateEmissionMatrix();
        void generateForwardMatrix();
        void generateBackwardMatrix();
        void EM();
        void setSeed(int seed);
        int getSeed();
        void setState(int state);
        int getState();
        void setMark(int mark);
        int getMark();
        void setChr(std::string chr);
        std::string getChr();
        void setBins(int bins);
        int getBins();
        virtual ~HMM();
    protected:
    private:
        int seed,state,mark,bins;
        Number px_f,px_b;
        std::string chr;
        std::vector<std::vector<Number>> emission;
        std::vector<std::vector<Number>> transition;
        std::vector<Number> start;
        std::vector<Number> end;
        std::vector<std::vector<int>> V;
        std::vector<std::vector<Number>> emissionMatrix,forwardMatrix,backwardMatrix;
};

#endif // HMM_H
