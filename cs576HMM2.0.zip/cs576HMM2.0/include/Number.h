#ifndef NUMBER_H
#define NUMBER_H
#include <algorithm>
#include <cmath>
#include <climits>
#include <iostream>
class Number
{
    public:
        Number(double value,long long power=0);
        Number();
        const Number operator+(const Number&)const;
        Number & operator+=(const Number&);
        const Number operator-(const Number&)const;
        const Number operator*(const Number&)const;
        Number & operator*=(const Number&);
        const Number operator/(const Number&)const;
        Number & operator=(const Number&);
        double getValue();
        long long getPower();

        virtual ~Number();
    protected:
    private:
        double value;
        long long power;
        void adjustNumber(Number&);
};

#endif // NUMBER_H
