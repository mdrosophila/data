Emission-Pkm.txt
Emission probablity from 51 chromosome states(51 rows) to 41 histone modification marks. It is random data between 0 and 1.

Transistion-bij.txt
Transition possibility from 51 states to 51 states. The transition between states is randomly distributed. Note: in HMM learning, this data should be set to 0, when the value falls below 1E-10.

InitK.txt
transition possibility from chromosome start state to 51 states, randomly distributed.

EndK.txt
transition possibility from 51 states to chromosome end state, randomly distributed.

chr1-length.txt
chromosome 1 nucleotide length and its 200 bp bin size.

chr1.txt
chromsome 1 marks for every bins. There is no gap in bins.
