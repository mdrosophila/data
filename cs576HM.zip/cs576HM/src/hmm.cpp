#include "hmm.h"
HMM::HMM(){
    seed=77;
    state=51;
    mark=41;
}
HMM::HMM(int seed,int state=51,int mark=41){
    this->seed=seed;
    this->state=state;
    this->mark=mark;
}
void HMM::setSeed(int seed){
    this->seed=seed;
}
int HMM::getSeed(){
    return seed;
}
void HMM::setState(int state=51){
    this->state=state;
}
int HMM::getState(){
    return state;
}
void HMM::setMark(int mark=41){
    this->mark=mark;
}
int HMM::getMark(){
    return mark;
}
void HMM::setChr(std::string chr){
    this->chr=chr;
}
std::string HMM::getChr(){
    return chr;
}
void HMM::setBins(int bins){
    this->bins=bins;
}
int HMM::getBins(){
    return bins;
}

void HMM::generateInitParameters(){
    //set seed for random number
    srand(seed);
    //generate random emission matrix
    for (int i=0;i<state;i++){
        std::vector<double> tmp;
        for (int j=0;j<mark;j++){
            tmp.push_back(0);
        }
        emission.push_back(tmp);
    }
    for (int i=0;i<state;i++){
        for (int j=0;j<mark;j++){
            emission[i][j]=rand()%100/100.0;
        }
    }
    //generate random transition matrix
    for (int i=0;i<state;i++){
        std::vector<double> tmp;
        for (int j=0;j<state;j++){
            tmp.push_back(0);
        }
        transition.push_back(tmp);
    }
    for (int i=0;i<state;i++){
        for (int j=0;j<1000;j++){
            transition[i][rand()%state]+=0.001;
        }
    }
    //transition matrix from start to K state
    for (int i=0;i<state;i++){
        start.push_back(0);
    }
    for (int i=0;i<1000;i++){
        start[rand()%state]+=0.001;
    }
    //transition matrix from K state to end state
    for (int i=0;i<state;i++){
        end.push_back(0);
    }
    for (int i=0;i<1000;i++){
        end[rand()%state]+=0.001;
    }
}
void HMM::writeStateToFile(){
    std::fstream Emission_Pkm,Transition_bij,InitK,EndK;
    Emission_Pkm.open("Emission-Pkm.txt",std::ios::out|std::ios::app);
    Transition_bij.open("Transition-bij.txt",std::ios::out|std::ios::app);
    InitK.open("InitK.txt",std::ios::out|std::ios::app);
    EndK.open("EndK.txt",std::ios::out|std::ios::app);
    Emission_Pkm<<chr<<" emission Pkm\n";
    for (int i=0;i<state;i++){
        for (int j=0;j<mark;j++){
            Emission_Pkm<<std::fixed<<std::setprecision(3)<<emission[i][j]<<" ";
        }
        Emission_Pkm<<"\n";
    }
    Transition_bij<<chr<<" transition bij\n";
    for (int i=0;i<state;i++){
        for (int j=0;j<state;j++){
            Transition_bij<<std::fixed<<std::setprecision(10)<<transition[i][j]<<" ";
        }
            Transition_bij<<"\n";
    }
    InitK<<chr<<" transition from start\n";
    for (int i=0;i<state;i++){
        InitK<<std::scientific<<start[i]<<" ";
    }
    InitK<<"\n";
    EndK<<chr<<" transition from end\n";
    for (int i=0;i<state;i++){
        EndK<<std::scientific<<end[i]<<" ";
    }
    EndK<<"\n";
}
void HMM::generateChr(){
    V.clear();
    std::ifstream combined2("combined2.txt");
    std::string line;
    bool chr_finished=false;
    while (getline(combined2,line)&&!chr_finished){
        std::stringstream ss(line);
        std::string str;
        ss>>str;
        if (str==chr){
            int curr_bin=0;
            std::vector<int> row;
            while(getline(combined2,line)){
                if (line=="") continue;
                if (line.find("chr")!=std::string::npos) {
                        chr_finished=true;
                        break;
                }
                std::stringstream ss(line);
                int pos;
                ss>>pos;
                while (curr_bin<pos/200){
                    row.clear();
                    for (int i=0;i<mark;i++){
                        row.push_back(0);
                    }
                    V.push_back(row);
                    curr_bin++;
                }
                row.clear();
                for (int i=0;i<mark;i++){
                    int value;
                    ss>>value;
                    row.push_back(value);
                }
                V.push_back(row);
                curr_bin++;
            }
            while (curr_bin<bins){
                row.clear();
                for (int i=0;i<mark;i++){
                    row.push_back(0);
                }
                V.push_back(row);
                curr_bin++;
            }
        }
    }
}
void HMM::generateEmissionMatrix(){
    emissionMatrix.clear();
    double value=1;
    for (int bin=0;bin<bins;bin++){
        std::vector<double>row;
        for (int k=0;k<state;k++){
            value=1;
            for (int m=0;m<mark;m++){
                value*=pow(emission[k][m],V[bin][m])*pow(1-emission[k][m],1-V[bin][m]);
            }
            row.push_back(value);
        }
        emissionMatrix.push_back(row);
    }
}
void HMM::writeMarkToFile(){
    std::fstream curr_chr(chr+".txt",std::ios::out|std::ios::trunc);
    std::string line;
    for (int i=0;i<bins;i++){
        curr_chr<<i*200<<" ";
        for (int j=0;j<mark;j++){
            curr_chr<<V[i][j]<<" ";
        }
        curr_chr<<"\n";
    }
}

void HMM::generateForwardMatrix(){
    forwardMatrix.clear();
    forwardScale.clear();
    double value=0;
    //init scale vector with size of chromosome bins
    for (int bin=0;bin<bins;bin++) forwardScale.push_back(0);
    //forward algorithm previous and current state
    std::vector<double> row;
    for (int k=0;k<state;k++){
        value=start[k]*emissionMatrix[0][k];
        row.push_back(value);
    }
    forwardMatrix.push_back(row);
    for (int bin=1;bin<bins;bin++){
        row.clear();
        for (int k=0;k<state;k++){
            double curr_state_val=0;
            for (int pk=0;pk<state;pk++){
                curr_state_val+=transition[pk][k]*forwardMatrix[bin-1][pk];
            }
            value=curr_state_val*emissionMatrix[bin][k];
            row.push_back(value);
        }
        double avg=0;
        for (int tk=0;tk<state;tk++){
            avg+=row[tk];
        }
        avg=avg/state;
        if (avg<1e-100) {
            forwardScale[bin]=forwardScale[bin-1]+100;
        }
        else forwardScale[bin]=forwardScale[bin-1];
        for (int tk=0;tk<state;tk++){
            row[tk]=row[tk]*pow(10,forwardScale[bin]-forwardScale[bin-1]);
        }
        forwardMatrix.push_back(row);
    }
    px_f=0;
    for (int k=0;k<state;k++){
        value=forwardMatrix[bins-1][k]*end[k];
        px_f+=value;
    }
    std::cout<<chr<<" probability px from forward algorithm is:"<<std::scientific<<px_f<<" "<<"scale factor is "<<forwardScale[bins-1]<<std::endl;
}
void HMM::readStateFromFile(){
    std::ifstream Emission_Pkm,Transition_bij,InitK,EndK;
    Emission_Pkm.open("Emission-Pkm.txt");
    Transition_bij.open("Transition-bij.txt");
    InitK.open("InitK.txt");
    EndK.open("EndK.txt");
    emission.clear();
    for (int i=0;i<state;i++){
        double value;
        std::vector<double> row;
        for (int j=0;j<mark;j++){
            Emission_Pkm>>value;
            row.push_back(value);
        }
        emission.push_back(row);
    }
    transition.clear();
    for (int i=0;i<state;i++){
        double value;
        std::vector<double> row;
        for (int j=0;j<state;j++){
            Transition_bij>>value;
            row.push_back(value);
        }
        transition.push_back(row);
    }
    start.clear();
    for (int i=0;i<state;i++){
        double value;
        InitK>>value;
        start.push_back(value);
    }
    end.clear();
    for (int i=0;i<state;i++){
        double value;
        EndK>>value;
        end.push_back(value);
    }
    Emission_Pkm.close();
    Transition_bij.close();
    InitK.close();
    EndK.close();
}
void HMM::printState(){
    std::cout<<"Emission state Pkm"<<std::endl;
    for (int i=0;i<state;i++){
        for (int j=0;j<mark;j++){
            std::cout<<std::fixed<<std::setprecision(3)<<emission[i][j]<<" ";
        }
        std::cout<<std::endl;
    }
    std::cout<<"State transition prob"<<std::endl;
    for (int i=0;i<state;i++){
        for (int j=0;j<state;j++){
            std::cout<<std::fixed<<std::setprecision(10)<<transition[i][j]<<" ";
        }
        std::cout<<std::endl;
    }
    std::cout<<"Transition from start"<<std::endl;
    for (int i=0;i<state;i++){
        std::cout<<std::scientific<<start[i]<<" ";
    }
    std::cout<<std::endl;
    std::cout<<"Transition from end"<<std::endl;
    for (int i=0;i<state;i++){
        std::cout<<std::scientific<<end[i]<<" ";
    }
    std::cout<<std::endl;
}

void HMM::generateBackwardMatrix(){
    backwardMatrix.clear();
    backwardScale.clear();
    double value;
    for (int bin=0;bin<bins;bin++) backwardScale.push_back(0);
    for (int bin=0;bin<bins;bin++){
        std::vector<double> row;
        for (int k=0;k<state;k++){
            row.push_back(0);
        }
        backwardMatrix.push_back(row);
    }
    for (int k=0;k<state;k++){
        backwardMatrix[bins-1][k]=end[k];
    }
    for (int bin=bins-2;bin>=0;bin--){
        std::vector<double>row;
        for (int k=0;k<state;k++){
            value=0;
            for (int nk=0;nk<state;nk++){
               value+=transition[k][nk]*emissionMatrix[bin+1][nk]*backwardMatrix[bin+1][nk];
            }
            row.push_back(value);
        }
        double avg=0;
        for (int k=0;k<state;k++){
            avg+=row[k];
        }
        avg=avg/state;
        if (avg<1e-100) {
            backwardScale[bin]=backwardScale[bin+1]+100;
        }
        else backwardScale[bin]=backwardScale[bin+1];
        for (int k=0;k<state;k++){
            row[k]=row[k]*pow(10,backwardScale[bin]-backwardScale[bin+1]);
            backwardMatrix[bin][k]=row[k];
        }
    }
    px_b=0;
    for (int k=0;k<state;k++){
        px_b+=start[k]*emissionMatrix[0][k]*backwardMatrix[0][k];
    }
    std::cout<<chr<<" probability px from backward algorithm is: "<<std::scientific<<px_b<<" scale factor:"<<backwardScale[0]<<std::endl;
}
void HMM::EM(){
    double value;
    std::vector<std::vector<double>> emissionNumerator(state,std::vector<double>(mark,0));
    std::vector<std::vector<double>> emissionDenominator(state,std::vector<double>(mark,0));
    std::vector<std::vector<double>> updatedEmission(state,std::vector<double>(mark,0));
    for (int k=0;k<state;k++){
        for (int m=0;m<mark;m++){
            for (int bin=0;bin<bins;bin++){

                //std::cout<<"f: "<<forwardMatrix[bin][k]<<" ";
                //std::cout<<"b:"<<backwardMatrix[bin][k]<<" ";
                //std::cout<<"m: "<<V[bin][m]<<" ";
                //std::cout<<"f_S:"<<forwardScale[bin]<<" b_S:"<<backwardScale[bin];
                value=forwardMatrix[bin][k]*backwardMatrix[bin][k];
                emissionNumerator[k][m]+=value*V[bin][m]*pow(10,forwardScale[bins-1]-forwardScale[bin]-backwardScale[bin])/px_f;
                emissionDenominator[k][m]+=value*pow(10,forwardScale[bins-1]-forwardScale[bin]-backwardScale[bin])/px_f;
                //std::cout<<" N: "<<emissionNumerator[k][m]<<" D: "<<emissionDenominator[k][m]<<std::endl;
                //std::cin.get();
            }
        }
    }
    for (int k=0;k<state;k++){
        for (int m=0;m<mark;m++){
            updatedEmission[k][m]=emissionNumerator[k][m]/emissionDenominator[k][m];
        }
    }
    std::vector<double> updatedStart(state,0);
    double sumStart=0;
    for (int k=0;k<state;k++){
        updatedStart[k]=start[k]*emissionMatrix[0][k]*backwardMatrix[0][k]/px_f;
        sumStart+=updatedStart[k];
    }
    for (int k=0;k<state;k++){
        updatedStart[k]/=sumStart;
    }
    std::vector<double> updatedEnd(state,0);
    double sumEnd=0;
    for (int k=0;k<state;k++){
        updatedEnd[k]=forwardMatrix[bins-1][k]*end[k]/px_f;
        sumEnd+=updatedEnd[k];
    }
    for (int k=0;k<state;k++){
        updatedEnd[k]/=sumEnd;
    }

    std::vector<std::vector<double>>updatedTransition(state,std::vector<double>(state,0));
    std::vector<double>sumTranisitonK(state,0);
    for (int k=0;k<state;k++){
        for (int nk=0;nk<state;nk++){
            for(int bin=0;bin<bins-1;bin++){
                updatedTransition[k][nk]+=forwardMatrix[bin][k]*transition[k][nk]*emissionMatrix[bin+1][nk]*backwardMatrix[bin+1][nk]/px_f;
            }
            sumTranisitonK[k]+=updatedTransition[k][nk];
        }
    }
    for (int k=0;k<state;k++){
        for (int nk=0;nk<state;nk++){
            updatedTransition[k][nk]=updatedTransition[k][nk]/sumTranisitonK[k];
        }
    }
    emission=updatedEmission;
    transition=updatedTransition;
    start=updatedStart;
    end=updatedEnd;
}
HMM::~HMM()
{
    //dtor
}
