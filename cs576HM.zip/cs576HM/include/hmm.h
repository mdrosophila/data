#ifndef HMM_H
#define HMM_H
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <vector>
#include <cmath>
class HMM
{
    public:
        HMM();
        HMM(int seed,int state,int mark);
        void generateInitParameters();
        void writeStateToFile();
        void readStateFromFile();
        void printState();
        void generateChr();
        void writeMarkToFile();
        void generateEmissionMatrix();
        void generateForwardMatrix();
        void generateBackwardMatrix();
        void EM();
        void setSeed(int seed);
        int getSeed();
        void setState(int state);
        int getState();
        void setMark(int mark);
        int getMark();
        void setChr(std::string chr);
        std::string getChr();
        void setBins(int bins);
        int getBins();
        virtual ~HMM();
    protected:
    private:
        int seed,state,mark,bins;
        double px_f,px_b;
        std::string chr;
        std::vector<std::vector<double>> emission;
        std::vector<std::vector<double>> transition;
        std::vector<double> start;
        std::vector<double> end;
        std::vector<int> forwardScale,backwardScale;
        std::vector<std::vector<int>> V;
        std::vector<std::vector<double>> emissionMatrix,forwardMatrix,backwardMatrix;
};

#endif // HMM_H
