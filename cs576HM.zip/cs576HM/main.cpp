#include <iostream>
#include "hmm.h"

using namespace std;

int main()
{
    int seed=77,state=2,mark=41;//seed of random number generator is 77.
    //It is used to generate random state emission probabilities and transition states.
    //total number states can be set from 2 to 80 and modification marks have to be 41.
    HMM hmm(seed,state,mark);//init HMM model with parameters.
    hmm.generateInitParameters();//initiate random transition states and emission states
    hmm.writeStateToFile();//save the state to File
    hmm.printState();

    hmm.setChr("chr1");//We learn chr1 first. It can be chr2-chr22,chrX,chrY
    hmm.setBins(1235999);//bin size of chr1 and it should be set based on the chromosome size249,250,62/200+1
    hmm.generateChr();//generate modification marks for chosen chromosome
    hmm.generateForwardMatrix();//generate forward matrix for chosen chromosome
    hmm.generateBackwardMatrix();//generate backward matrix for chosen chromosome
    hmm.EM();//update transition and emission state
    hmm.writeStateToFile();//save the state to File
    hmm.printState();

    //choose to learn next chromosome for example chr2
    hmm.setChr("chr2");//Learn next chromosome. It can be chr2-chr22,chrX,chrY
    hmm.setBins(1215997);//bin size of chr2 and it should be set based on the chromosome size243,199,373/200+1
    hmm.generateChr();//generate modification marks for chosen chromosome
    hmm.generateForwardMatrix();//generate forward matrix for chosen chromosome
    hmm.generateBackwardMatrix();//generate backward matrix for chosen chromosome
    hmm.EM();//update transition and emission state
    hmm.writeStateToFile();//save the state to File
    hmm.printState();
    return 0;
}
