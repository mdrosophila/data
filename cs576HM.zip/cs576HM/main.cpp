#include <iostream>
#include "hmm.h"

using namespace std;

int main()
{
    //chromose bin numbers from chromosome 1 to 22, to X, and to Y. Bin size is 200bp
    int chrBin[25]={0,1235999, 1213756,997234, 956315,904189, 854485,794107, 731374, 702211, 676874, 672262, 661448,
     570640, 531803, 501695, 444111, 393274, 380586, 319033, 312180, 234722, 247645, 774569, 288708};

    int seed=77,state=2,mark=41;//seed of random number generator is 77.
    //It is used to generate random state emission probabilities and transition states.
    //total number states can be set from 2 to 80 and modification marks have to be 41.
    HMM hmm(seed,state,mark);//init HMM model with parameters.
    hmm.generateInitParameters();//initiate random transition states and emission states
    hmm.writeStateToFile();//save the state to File
    hmm.printState();
    for (int i=1;i<25;i++){
        if (i==23) hmm.setChr("chrX");
        else if (i==24) hmm.setChr("chrY");
        else {
            stringstream ss;
            string tmp;
            ss<<i;
            ss>>tmp;
            hmm.setChr("chr"+tmp);
        }
        //We learn chr1 first. It can be chr2-chr22,chrX,chrY
        hmm.setBins(chrBin[i]);//bin size of chr1 and it should be set based on the chromosome size/200+1
        hmm.generateChr();//generate modification marks for chosen chromosome
        hmm.generateEmissionMatrix();//cached the expensive emission state calculation
        hmm.generateForwardMatrix();//generate forward matrix for chosen chromosome
        hmm.generateBackwardMatrix();//generate backward matrix for chosen chromosome
        hmm.EM();//update transition and emission state
        hmm.writeStateToFile();//save the state to File
        hmm.printState();
    }

    return 0;
}
